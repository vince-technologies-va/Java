package java4;

public class rohan1 {
    public static void main(String[] args) {
        int x = 5;
        int y = 4;
        boolean result = x < y;
        System.out.println(result);
    }
}
