abstract class A {
    abstract void display();
}

abstract class B extends a {
    void display() {
        System.out.println("classs A");
    }

}

class Abstract {
    public static void main(String args[]) {
        B.c = new B();
        c.display();

    }

}
