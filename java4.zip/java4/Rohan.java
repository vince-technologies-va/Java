class Human

{
    private int gfNumber;
    private String gfType;

    public int getGfNumber() {
        return gfNumber;
    }

    public void setGfNumber(int a) {
        gfNumber = a;
    }

    public String getGfType() {
        return gfType;
    }

    public void setGfType(String n) {
        gfType = n;
    }

}

public class Rohan {
    public static void main(String args[]) {
        Human h = new Human();
        h.setGfNumber(6);
        h.setGfType(".......");

        System.out.println(h.getGfNumber() + ":" + h.getGfType());

    }
}