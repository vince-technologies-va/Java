class Animalss {
    static void run1() {
        System.out.println("animal is running");
    }

    void run2()

    {
        System.out.println("animal is running");
    }
}

class Cheetah extends Animalss(){

    static void run1() {
        System.out.println("cheetah is running");
    }

    void run2() {
        System.out.println("cheetah is running");
    }

}

public class Run {
    public static void main(String a[]) {
        Animalss a = new Cheetah();
        a.run1();
        a.run2();

    }
}